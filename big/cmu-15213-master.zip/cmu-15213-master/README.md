Labs for Computer Systems: A Programmer's Perspective, 3/E (CS:APP3e), its corresponding course is 15-213: Introduction to Computer Systems (ICS), Carnegie Mellon University.
