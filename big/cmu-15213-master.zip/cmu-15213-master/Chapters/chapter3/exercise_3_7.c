long scale2(long x, long y, long z) {
	long t = 5 * x + 2 * y + 8 * z;
	return t;
}
