typedef unsigned char* byte_pointer;

void show_bytes(byte_pointer start, size_t len);
