/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_142()
{
    return 2425387259U;
}

unsigned addval_273(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_219(unsigned x)
{
    return x + 2421715793U;
}

void setval_237(unsigned *p)
{
    *p = 3351742792U;
}

void setval_424(unsigned *p)
{
    *p = 2455290452U;
}

void setval_470(unsigned *p)
{
    *p = 3347925091U;
}

void setval_426(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_280()
{
    return 3281016873U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_481()
{
    return 2428668252U;
}

void setval_296(unsigned *p)
{
    *p = 2425409945U;
}

unsigned addval_113(unsigned x)
{
    return x + 3380137609U;
}

unsigned addval_490(unsigned x)
{
    return x + 3676361101U;
}

unsigned getval_226()
{
    return 3225997705U;
}

void setval_384(unsigned *p)
{
    *p = 3229929857U;
}

unsigned addval_190(unsigned x)
{
    return x + 3767093313U;
}

void setval_276(unsigned *p)
{
    *p = 3372794504U;
}

unsigned addval_436(unsigned x)
{
    return x + 2425409161U;
}

unsigned getval_345()
{
    return 3252717896U;
}

unsigned addval_479(unsigned x)
{
    return x + 3372270217U;
}

unsigned addval_187(unsigned x)
{
    return x + 3224948361U;
}

void setval_248(unsigned *p)
{
    *p = 3674787457U;
}

unsigned getval_159()
{
    return 3375944073U;
}

unsigned addval_110(unsigned x)
{
    return x + 3286272456U;
}

unsigned addval_487(unsigned x)
{
    return x + 3229926025U;
}

unsigned addval_201(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_272()
{
    return 3523793305U;
}

unsigned getval_155()
{
    return 3385115273U;
}

void setval_299(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_404(unsigned x)
{
    return x + 3281178249U;
}

unsigned getval_311()
{
    return 3674788233U;
}

void setval_167(unsigned *p)
{
    *p = 3281113481U;
}

void setval_328(unsigned *p)
{
    *p = 3526935169U;
}

void setval_450(unsigned *p)
{
    *p = 3372797449U;
}

unsigned addval_358(unsigned x)
{
    return x + 2430634248U;
}

unsigned addval_124(unsigned x)
{
    return x + 1019724425U;
}

unsigned getval_169()
{
    return 3223375496U;
}

void setval_181(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_184(unsigned x)
{
    return x + 3529556617U;
}

unsigned getval_472()
{
    return 3525365389U;
}

void setval_350(unsigned *p)
{
    *p = 2430634312U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
